package flipkart.exception;

/**
 * Created by sharanya.p on 1/13/2018.
 */
public class UserException extends Exception {

    public UserException(String s) {
        super(s);
    }

}
